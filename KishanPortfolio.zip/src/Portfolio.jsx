
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Download } from "lucide-react";

export default function Portfolio() {
  return (
    <div className="p-6 max-w-4xl mx-auto">
      <div className="flex items-center gap-6 mb-6">
        <img
          src="/profile.jpg"
          alt="Kishan Sai Venkata Vivek Chandaluri"
          className="w-32 h-32 rounded-full shadow-lg object-cover"
        />
        <div>
          <h1 className="text-3xl font-bold">Kishan Sai Venkata Vivek Chandaluri</h1>
          <p className="text-sm text-gray-600">Guntur, Andhra Pradesh, India</p>
          <p className="text-sm">📧 kishanchandaluri@gmail.com | 📞 +91 7989350585</p>
          <div className="flex gap-4 mt-2">
            <a href="https://www.linkedin.com/in/kishan-sai-venkata-vivek-chandaluri-67225a2ba/" target="_blank" className="text-blue-600 hover:underline">LinkedIn</a>
            <a href="https://github.com/kishan-s-v-v" target="_blank" className="text-blue-600 hover:underline">GitHub</a>
          </div>
        </div>
      </div>

      <Card className="mb-6">
        <CardContent className="p-4">
          <h2 className="text-xl font-semibold mb-2">About Me</h2>
          <p>
            I am a passionate Computer Science and Engineering student at Lovely Professional University, with a focus on data-driven solutions and hands-on experience in machine learning and data science. I enjoy solving complex problems and exploring meaningful patterns through data.
          </p>
        </CardContent>
      </Card>

      <Card className="mb-6">
        <CardContent className="p-4">
          <h2 className="text-xl font-semibold mb-2">Projects</h2>
          <div className="mb-4">
            <h3 className="font-semibold">Telecom Customer Churn Analysis (Sep 2024 – Dec 2024)</h3>
            <ul className="list-disc list-inside ml-4 text-sm">
              <li>Analyzed customer data using Python, Pandas, and Scikit-learn.</li>
              <li>Identified service quality and pricing factors influencing churn.</li>
              <li>Recommended retention strategies.</li>
              <li><a href="https://github.com/kishan-s-v-v/Telecom-Customer-Churn-EDA" target="_blank" className="text-blue-600 hover:underline">GitHub Repo</a></li>
            </ul>
          </div>

          <div>
            <h3 className="font-semibold">Black Friday Sales Analysis (Jun 2024 – Aug 2024)</h3>
            <ul className="list-disc list-inside ml-4 text-sm">
              <li>Exploratory data analysis of customer behavior and sales trends.</li>
              <li>Utilized Python, Matplotlib, Seaborn, and Plotly.</li>
            </ul>
          </div>
        </CardContent>
      </Card>

      <Card className="mb-6">
        <CardContent className="p-4">
          <h2 className="text-xl font-semibold mb-2">Training & Certifications</h2>
          <ul className="list-disc list-inside ml-4 text-sm">
            <li>Machine Learning & Data Science (GeeksforGeeks) - <a href="https://media.geeksforgeeks.org/courses/certificates/1a1903e3f38789bddfd5c0bddf90ed23.pdf" target="_blank" className="text-blue-600 hover:underline">Certificate</a></li>
            <li>Fundamentals of Kotlin (Coursera) - <a href="https://www.coursera.org/learn/meta-programming-fundamentals-kotlin?specialization=meta-android-developer" target="_blank" className="text-blue-600 hover:underline">Course Link</a></li>
          </ul>
        </CardContent>
      </Card>

      <Card className="mb-6">
        <CardContent className="p-4">
          <h2 className="text-xl font-semibold mb-2">Technical Skills</h2>
          <ul className="list-disc list-inside ml-4 text-sm">
            <li><strong>Languages:</strong> Java, Python, Kotlin, HTML</li>
            <li><strong>Frameworks/Tools:</strong> MySQL, JavaScript, Kotlin</li>
            <li><strong>Core Skills:</strong> Problem-Solving, DSA, Project Management, Adaptability</li>
          </ul>
        </CardContent>
      </Card>

      <Card className="mb-6">
        <CardContent className="p-4">
          <h2 className="text-xl font-semibold mb-2">Education</h2>
          <ul className="list-disc list-inside ml-4 text-sm">
            <li><strong>Lovely Professional University</strong> – B.Tech CSE (2022–Present), CGPA: 6.98</li>
            <li><strong>Narayana Junior College</strong> – 12th Science (2020–2022), 78%</li>
            <li><strong>Viswa Bharathi High School</strong> – 10th (2019–2020), CGPA: 9.8</li>
          </ul>
        </CardContent>
      </Card>

      <div className="flex justify-center">
        <a href="/cvsep.pdf" download>
          <Button className="flex items-center gap-2">
            <Download size={16} /> Download Resume
          </Button>
        </a>
      </div>
    </div>
  );
}
